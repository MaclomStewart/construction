<?php
if(is_admin()){
	require get_template_directory() . '/admin/inc/class-webriti-about-page.php';
}

require get_template_directory() . '/admin/inc/plugin-include-control.php';
require get_template_directory() . '/admin/inc/include-companion.php';


